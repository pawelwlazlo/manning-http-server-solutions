fn main() {
  let s : &str = "Hello Paweł!";
  println!("{}", s);
}
